// JavaScript Document
jQuery( document ).bind( "mobileinit", function($){
    $.mobile.page.prototype.options.degradeInputs.date = true;
  });	